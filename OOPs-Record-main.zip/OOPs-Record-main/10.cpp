#include<iostream>
#include<iomanip>
using namespace std;
inline int A(int x)
{
    return x*x;
}
int main()
{
    cout<<A(5)<<endl;
    cout<<A(10);
}